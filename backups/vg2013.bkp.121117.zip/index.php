<?php include ("get_template_directory_uri(); . /functions.php"); ?>
<!doctype html>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php if (is_home() || is_front_page()) { echo bloginfo('name'); } else { echo wp_title(''); } ?></title>
	<link href="<?php echo get_template_directory_uri(); ?>/style.css" type="text/css" rel="stylesheet" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php echo bloginfo('rss2_url'); ?>">
	<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js?ver=3.4.2'></script>
	<script type="text/javascript">
		$(window).scroll(function(){
		var scrollPos = $(document).scrollTop();
		$("#bg").css("top", -scrollPos/3+"px");
		}); 
	</script>
</head>
<body>
	<table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td>
		<div id="bg"></div>
		<img id="header" src="<?php echo get_template_directory_uri(); ?>/images/header.png" />
		<div id="container">
			<div id="right-column" class="shadow2">
				<img class="post-top shadow" src="<?php echo get_template_directory_uri(); ?>/images/post_top.png" />
				<div class="post">
					<?php // the loop ?>
					<?php if (have_posts()) : ?>
						<?php while (have_posts()) : the_post(); ?>
							<?php get_template_part( 'includes/loop' , 'index'); ?>
						<?php endwhile; ?>			
						<?php get_template_part( 'includes/pagination'); ?>
					<?php else : ?>
						<p><?php _e( 'Sorry, nothing found.', 'themify' ); ?></p>
					<?php endif; ?>	
				</div>
				<img class="post-bottom" src="<?php echo get_template_directory_uri(); ?>/images/post_bottom.png" />
			</div>
			<div id="left-column">
				<div id="navigation">
					<?php wp_nav_menu( array( 'theme_location' => 'navigation', 'container_class' => 'navigation' ) ); ?>
				</div>
				<div id="ads">
					<p>Ads</p>
				</div>
			</div>
		</div>
	</td></tr><tr><td>
		<img id="footer" src="<?php echo get_template_directory_uri(); ?>/images/footer.png" />
	</td></tr></table>
</body>
