<!doctype html>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php if (is_home() || is_front_page()) { echo bloginfo('name'); } else { echo wp_title(''); } ?></title>
	<link href="<?php echo get_template_directory_uri(); ?>/style.css" type="text/css" rel="stylesheet" />
	<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php echo bloginfo('rss2_url'); ?>">
	<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js?ver=3.4.2'></script>
	<script type="text/javascript">
		$(window).scroll(function(){
		var scrollPos = $(document).scrollTop();
		$("#bg").css("top", -scrollPos/3+"px");
		}); 
	</script>
</head>
<body>
	<div id="bg"></div>
	<img id="header" src="<?php echo get_template_directory_uri(); ?>/images/header.png" />
	<div id="container">
		<div id="right-column">
			<img class="post-top" src="<?php echo get_template_directory_uri(); ?>/images/post_top.png" />
			<div class="post">
				<h1>lkjlkj</h1>
				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>				<p>ljalksjf öalskdjfö alsdkjf öalsdkjf öalskdjf öalskdjföalsk djföalksdj föalskdfj aölskdjf öalskjd f</p>
				<p>asdflkjalsdkfj öalksdjfalöksdjdf öalkdjfalöksdjf aöldskjfjalskdjfalkdfj öalskdjföalksjdf </p>
				<p>asdlfkj öalskjdji awörelij öflaijwretöawiejr ölaisjdfölij awe</p>
			</div>
			<img class="post-bottom" src="<?php echo get_template_directory_uri(); ?>/images/post_bottom.png" />
		</div>
		<div id="left-column">
			<div id="navigation">
				<?php wp_nav_menu(); ?>
			</div>
			<div id="ads">
				<p>Ads</p>
			</div>
		</div>
	</div>
</body>
